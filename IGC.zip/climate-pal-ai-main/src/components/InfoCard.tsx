import { ReactNode } from "react";

interface InfoCardProps {
  title?: string;
  children: ReactNode;
  variant?: "default" | "highlight";
}

const InfoCard = ({ title, children, variant = "default" }: InfoCardProps) => {
  const variantClasses = {
    default: "bg-card hover:shadow-medium",
    highlight: "bg-gradient-card hover:shadow-medium border-2 border-secondary",
  };

  return (
    <div
      className={`rounded-lg p-6 transition-all duration-300 shadow-soft ${variantClasses[variant]} animate-fade-in`}
    >
      {title && (
        <h3 className="text-xl font-semibold text-primary mb-3 border-l-4 border-accent pl-3">
          {title}
        </h3>
      )}
      <div className="text-foreground/80 leading-relaxed">{children}</div>
    </div>
  );
};

export default InfoCard;
