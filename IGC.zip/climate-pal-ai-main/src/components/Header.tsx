import { Link, useLocation } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Leaf } from "lucide-react";

const Header = () => {
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path;

  return (
    <header className="fixed top-0 left-0 right-0 z-50 bg-background/80 backdrop-blur-md border-b border-border">
      <nav className="container mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 text-primary font-semibold text-xl hover:opacity-80 transition-opacity">
          <Leaf className="h-6 w-6" />
          <span>Environmental Buddy</span>
        </Link>

        <div className="flex items-center gap-6">
          <Link
            to="/about"
            className={`text-sm font-medium transition-colors hover:text-primary ${
              isActive("/about") ? "text-primary" : "text-foreground/70"
            }`}
          >
            About
          </Link>
          <Link
            to="/carbon-calculator"
            className={`text-sm font-medium transition-colors hover:text-primary ${
              isActive("/carbon-calculator") ? "text-primary" : "text-foreground/70"
            }`}
          >
            Calculator
          </Link>
          <Link to="/signup">
            <Button variant="outline" size="sm">
              Sign Up
            </Button>
          </Link>
          <Link to="/signin">
            <Button size="sm">
              Sign In
            </Button>
          </Link>
        </div>
      </nav>
    </header>
  );
};

export default Header;
