import heroImage from "@/assets/hero-environment.jpg";

interface HeroProps {
  title: string;
  subtitle?: string;
  height?: "full" | "large" | "medium";
}

const Hero = ({ title, subtitle, height = "full" }: HeroProps) => {
  const heightClasses = {
    full: "min-h-screen",
    large: "min-h-[70vh]",
    medium: "min-h-[50vh]",
  };

  return (
    <section
      className={`relative ${heightClasses[height]} flex items-center justify-center overflow-hidden`}
      style={{
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.4), rgba(0, 0, 0, 0.3)), url(${heroImage})`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        backgroundAttachment: "fixed",
      }}
    >
      <div className="container mx-auto px-4 text-center z-10 animate-fade-in-up">
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white mb-4 drop-shadow-lg">
          {title}
        </h1>
        {subtitle && (
          <p className="text-lg md:text-xl text-white/90 max-w-2xl mx-auto drop-shadow-md">
            {subtitle}
          </p>
        )}
      </div>
    </section>
  );
};

export default Hero;
