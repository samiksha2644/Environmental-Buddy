import { Leaf } from "lucide-react";

const Footer = () => {
  return (
    <footer className="bg-primary text-primary-foreground">
      <div className="container mx-auto px-4 py-8">
        <div className="flex flex-col items-center gap-4">
          <div className="flex items-center gap-2">
            <Leaf className="h-5 w-5" />
            <span className="font-semibold">Environmental Buddy</span>
          </div>
          <p className="text-sm text-primary-foreground/80 text-center">
            © 2025 Environmental Education & Climate Literacy | Designed for a Greener Tomorrow
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
