import Header from "@/components/Header";
import Footer from "@/components/Footer";
import InfoCard from "@/components/InfoCard";
import ScrollToTop from "@/components/ScrollToTop";
import aboutHero from "@/assets/about-hero.jpg";

const About = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />

      {/* Hero Section */}
      <section
        className="relative min-h-[50vh] flex items-center justify-center mt-16"
        style={{
          backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.4)), url(${aboutHero})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <h1 className="text-4xl md:text-6xl font-bold text-white drop-shadow-lg animate-fade-in">
          About Environmental Buddy
        </h1>
      </section>

      {/* Content Sections */}
      <div className="container mx-auto px-4 py-16 space-y-12 max-w-5xl">
        {/* Problem Statement */}
        <section className="animate-fade-in-up">
          <h2 className="text-3xl font-bold text-primary mb-6 border-l-4 border-accent pl-4">
            Problem Statement: Tackling the Climate Awareness Gap
          </h2>
          <p className="text-lg text-foreground/80 leading-relaxed">
            Many people are unaware that their everyday actions — like wasting water, overusing plastic, or leaving
            lights on — directly contribute to climate change and global warming. Because climate education is often
            complex and unengaging, individuals don't realize their role in environmental impact and rarely take
            meaningful daily action.
          </p>
        </section>

        {/* Why It Matters */}
        <section className="animate-fade-in-up">
          <h2 className="text-3xl font-bold text-primary mb-6 border-l-4 border-accent pl-4">
            Why This Problem Matters
          </h2>
          <InfoCard variant="highlight">
            <ul className="space-y-3">
              <li className="flex items-start gap-3">
                <span className="text-accent text-xl mt-1">•</span>
                <span>Climate change is a global emergency, yet personal contributions are often ignored.</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-accent text-xl mt-1">•</span>
                <span>
                  Education around climate change is too complex, fragmented, and technical for the general public.
                </span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-accent text-xl mt-1">•</span>
                <span>Real impact starts at the grassroots — millions of small sustainable habits can create massive change.</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-accent text-xl mt-1">•</span>
                <span>
                  There's a need for personalized, interactive, and motivating platforms that link science to everyday
                  life.
                </span>
              </li>
            </ul>
          </InfoCard>
        </section>

        {/* Current Gaps */}
        <section className="animate-fade-in-up">
          <h2 className="text-3xl font-bold text-primary mb-6 border-l-4 border-accent pl-4">
            Current Gaps in Existing Solutions
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            <InfoCard title="Complexity">
              <p>Too scientific and text-heavy for general audiences.</p>
            </InfoCard>
            <InfoCard title="Scattered Resources">
              <p>No unified hub for comprehensive climate education.</p>
            </InfoCard>
            <InfoCard title="Low Engagement">
              <p>Lack of interactivity and gamification elements.</p>
            </InfoCard>
            <InfoCard title="No Personalization">
              <p>One-size-fits-all approach doesn't fit all regions or cultures.</p>
            </InfoCard>
            <InfoCard title="Weak Retention">
              <p>People learn but forget, without motivation to continue.</p>
            </InfoCard>
          </div>
        </section>

        {/* Vision */}
        <section className="animate-fade-in-up">
          <h2 className="text-3xl font-bold text-primary mb-6 border-l-4 border-accent pl-4">Our Vision</h2>
          <InfoCard variant="highlight">
            <p className="text-lg">
              To build an <strong>AI-powered interactive platform</strong> that makes climate education simple, fun, and
              personalized — turning awareness into everyday sustainable actions.
            </p>
          </InfoCard>
        </section>

        {/* What We Offer */}
        <section className="animate-fade-in-up">
          <h2 className="text-3xl font-bold text-primary mb-6 border-l-4 border-accent pl-4">
            What Environmental Buddy Offers
          </h2>
          <InfoCard>
            <ul className="space-y-4">
              <li>
                <strong className="text-primary">Educates:</strong> Learn through quizzes, micro-lessons, and
                myth-busting facts.
              </li>
              <li>
                <strong className="text-primary">Engages:</strong> Take part in gamified eco-challenges and earn
                rewards.
              </li>
              <li>
                <strong className="text-primary">Personalizes:</strong> AI tailors tips to your habits, region, and
                interests.
              </li>
              <li>
                <strong className="text-primary">Guides:</strong> A chatbot mentor provides real-time sustainable
                alternatives.
              </li>
              <li>
                <strong className="text-primary">Unifies:</strong> Combines all environmental resources into one
                engaging ecosystem.
              </li>
            </ul>
          </InfoCard>
        </section>

        {/* Conclusion */}
        <section className="animate-fade-in-up">
          <h2 className="text-3xl font-bold text-primary mb-6 border-l-4 border-accent pl-4">
            Unique Features of Environmental Buddy
          </h2>
          <div className="grid md:grid-cols-2 gap-6">
            <InfoCard title="Quizzes & Rewards">
              <p className="mb-3"><strong>What it Does:</strong></p>
              <ul className="list-disc ml-5 mb-3 text-sm">
                <li>Engages users with interactive quizzes on environmental awareness.</li>
                <li>Rewards users for completing eco-friendly tasks and challenges.</li>
              </ul>
              <p className="mb-3"><strong>How it Works:</strong></p>
              <ul className="list-disc ml-5 mb-3 text-sm">
                <li>Gamified quizzes test knowledge on sustainability and climate change.</li>
                <li>Users complete small green actions (e.g., reducing plastic, saving energy) to earn points.</li>
                <li>A reward system tracks progress and motivates continuous participation.</li>
              </ul>
              <p className="mb-3"><strong>Impact:</strong></p>
              <ul className="list-disc ml-5 text-sm">
                <li>Makes learning about the environment fun and interactive.</li>
                <li>Encourages consistent eco-friendly behavior through positive reinforcement.</li>
                <li>Builds long-term awareness and habits that benefit individuals and the planet.</li>
              </ul>
            </InfoCard>

            <InfoCard title="Carbon Footprint Calculator">
              <p className="mb-3"><strong>What it Does:</strong></p>
              <p className="mb-3 text-sm">Helps users measure their personal CO₂ emissions based on lifestyle choices.</p>
              <p className="mb-3"><strong>How it Works:</strong></p>
              <ul className="list-disc ml-5 mb-3 text-sm">
                <li>Inputs: Transport, electricity use, diet, waste, flights.</li>
                <li>Emission Factors: Predefined CO₂ values (e.g., 1 km car = 0.21 kg CO₂, 1 kWh electricity = 0.82 kg CO₂).</li>
                <li>Calculation: Footprint = Σ (User Input × Emission Factor)</li>
              </ul>
              <p className="mb-3 text-sm"><strong>Output:</strong> Annual footprint in tonnes + comparison with India & global average.</p>
              <p className="text-sm"><strong>Impact:</strong> Educates, raises awareness, and motivates users to adopt greener habits.</p>
            </InfoCard>

            <InfoCard title="Announcements & Open Section">
              <p className="mb-3"><strong>What it Does:</strong></p>
              <ul className="list-disc ml-5 mb-3 text-sm">
                <li>Provides a platform for users to connect, share eco-friendly ideas, and collaborate.</li>
                <li>Delivers verified announcements on environmental news, events, and campaigns.</li>
              </ul>
              <p className="mb-3"><strong>How it Works:</strong></p>
              <ul className="list-disc ml-5 mb-3 text-sm">
                <li>Central hub for community posts, discussions, and idea sharing.</li>
                <li>Announcement board for updates on drives, webinars, and sustainability activities.</li>
                <li>Highlights & notifications to ensure timely participation.</li>
              </ul>
              <p className="mb-3"><strong>Impact:</strong></p>
              <ul className="list-disc ml-5 text-sm">
                <li>Builds an engaged, eco-conscious community.</li>
                <li>Encourages collective action through real-time event updates.</li>
                <li>Strengthens awareness and motivates users to take part in real-world initiatives.</li>
              </ul>
            </InfoCard>

            <InfoCard title="AI Chatbot & Info Hub">
              <p className="mb-3"><strong>What it Does:</strong></p>
              <ul className="list-disc ml-5 mb-3 text-sm">
                <li>Provides instant, interactive guidance on sustainability and eco-friendly practices.</li>
                <li>Acts as a smart knowledge hub with curated information on environmental topics.</li>
              </ul>
              <p className="mb-3"><strong>How it Works:</strong></p>
              <ul className="list-disc ml-5 mb-3 text-sm">
                <li>API-based chatbot answers user queries in real time with personalized suggestions.</li>
                <li>Info Hub fetches reliable data through APIs (news, research, government reports).</li>
                <li>Integrated system ensures accurate, updated, and accessible environmental knowledge.</li>
              </ul>
              <p className="mb-3"><strong>Impact:</strong></p>
              <ul className="list-disc ml-5 text-sm">
                <li>Simplifies complex information into actionable tips for users.</li>
                <li>Empowers individuals with verified, real-time knowledge to make greener choices.</li>
                <li>Creates an always-available digital assistant that enhances user engagement and trust.</li>
              </ul>
            </InfoCard>
          </div>
        </section>

        {/* Conclusion */}
        <section className="animate-fade-in-up">
          <h2 className="text-3xl font-bold text-primary mb-6 border-l-4 border-accent pl-4">Conclusion</h2>
          <InfoCard variant="highlight">
            <p className="text-lg">
              <strong>Environmental Buddy</strong> merges learning, engagement, and real-time AI guidance to make
              sustainability an interactive journey. By educating through quizzes, motivating through rewards,
              connecting communities, and guiding users with smart insights, we aim to inspire collective action for a
              greener, more sustainable planet.
            </p>
          </InfoCard>
        </section>
      </div>

      <ScrollToTop />
      <Footer />
    </div>
  );
};

export default About;
