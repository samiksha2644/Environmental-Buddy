import { useState } from "react";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import ScrollToTop from "@/components/ScrollToTop";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Calculator, Leaf } from "lucide-react";

const CarbonCalculator = () => {
  const [transport, setTransport] = useState("");
  const [electricity, setElectricity] = useState("");
  const [waste, setWaste] = useState("");
  const [flights, setFlights] = useState("");
  const [result, setResult] = useState<number | null>(null);

  const calculateFootprint = () => {
    // Emission factors (simplified example)
    const transportEmission = parseFloat(transport) * 0.21; // kg CO2 per km
    const electricityEmission = parseFloat(electricity) * 0.82; // kg CO2 per kWh
    const wasteEmission = parseFloat(waste) * 0.5; // kg CO2 per kg waste
    const flightEmission = parseFloat(flights) * 90; // kg CO2 per flight hour

    const total = transportEmission + electricityEmission + wasteEmission + flightEmission;
    const annualTonnes = total / 1000; // Convert to tonnes
    setResult(annualTonnes);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <ScrollToTop />

      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10 animate-fade-in-up">
            <div className="flex items-center justify-center gap-3 mb-4">
              <Calculator className="h-10 w-10 text-primary" />
              <h1 className="text-4xl md:text-5xl font-black text-foreground">
                Carbon Footprint Calculator
              </h1>
            </div>
            <p className="text-lg text-muted-foreground">
              Measure your personal CO₂ emissions and discover ways to reduce your environmental impact
            </p>
          </div>

          <Card className="shadow-medium mb-8">
            <CardHeader>
              <CardTitle className="text-2xl flex items-center gap-2">
                <Leaf className="h-6 w-6 text-primary" />
                Calculate Your Annual Carbon Footprint
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label htmlFor="transport">Daily Transport (km)</Label>
                  <Input
                    id="transport"
                    type="number"
                    placeholder="e.g., 20"
                    value={transport}
                    onChange={(e) => setTransport(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">Average km traveled per day by car/bike</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="electricity">Monthly Electricity (kWh)</Label>
                  <Input
                    id="electricity"
                    type="number"
                    placeholder="e.g., 300"
                    value={electricity}
                    onChange={(e) => setElectricity(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">Average electricity consumption per month</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="waste">Weekly Waste (kg)</Label>
                  <Input
                    id="waste"
                    type="number"
                    placeholder="e.g., 15"
                    value={waste}
                    onChange={(e) => setWaste(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">Average waste generated per week</p>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="flights">Annual Flight Hours</Label>
                  <Input
                    id="flights"
                    type="number"
                    placeholder="e.g., 10"
                    value={flights}
                    onChange={(e) => setFlights(e.target.value)}
                  />
                  <p className="text-xs text-muted-foreground">Total hours spent flying per year</p>
                </div>
              </div>

              <Button onClick={calculateFootprint} className="w-full" size="lg">
                Calculate My Footprint
              </Button>

              {result !== null && (
                <div className="mt-6 p-6 bg-gradient-card border-2 border-accent rounded-lg animate-fade-in">
                  <h3 className="text-xl font-semibold text-primary mb-4">Your Annual Carbon Footprint</h3>
                  <div className="text-center">
                    <p className="text-5xl font-black text-foreground mb-2">
                      {result.toFixed(2)} <span className="text-2xl">tonnes</span>
                    </p>
                    <p className="text-sm text-muted-foreground mb-4">CO₂ per year</p>
                  </div>

                  <div className="grid md:grid-cols-2 gap-4 mt-6">
                    <div className="bg-card p-4 rounded-lg">
                      <p className="text-sm text-muted-foreground mb-1">India Average</p>
                      <p className="text-2xl font-bold text-foreground">1.9 tonnes</p>
                    </div>
                    <div className="bg-card p-4 rounded-lg">
                      <p className="text-sm text-muted-foreground mb-1">Global Average</p>
                      <p className="text-2xl font-bold text-foreground">4.0 tonnes</p>
                    </div>
                  </div>

                  <div className="mt-6 p-4 bg-primary/10 rounded-lg">
                    <h4 className="font-semibold text-primary mb-2">💡 Personalized Eco-Tips</h4>
                    <ul className="text-sm space-y-2 text-foreground/80">
                      <li>• Use public transport or carpool to reduce transport emissions</li>
                      <li>• Switch to LED bulbs and unplug devices when not in use</li>
                      <li>• Reduce, reuse, and recycle to minimize waste</li>
                      <li>• Choose video calls over air travel when possible</li>
                      <li>• Plant trees to offset your carbon footprint</li>
                    </ul>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>

          <div className="bg-card p-6 rounded-lg shadow-soft">
            <h3 className="text-xl font-semibold text-primary mb-4">How It Works</h3>
            <div className="space-y-3 text-foreground/80">
              <p><strong>Inputs:</strong> Transport, electricity use, diet, waste, flights</p>
              <p><strong>Emission Factors:</strong> Predefined CO₂ values (e.g., 1 km car = 0.21 kg CO₂, 1 kWh electricity = 0.82 kg CO₂)</p>
              <p><strong>Calculation:</strong> Footprint = Σ (User Input × Emission Factor)</p>
              <p><strong>Impact:</strong> Educates, raises awareness, and motivates users to adopt greener habits</p>
            </div>
          </div>
        </div>
      </div>

      <Footer />
    </div>
  );
};

export default CarbonCalculator;
