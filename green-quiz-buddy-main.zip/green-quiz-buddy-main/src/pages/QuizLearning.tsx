import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Droplets, Wind, Trees, Sun, Trash2, 
  Leaf, Zap, Mountain, Waves, PawPrint,
  Award, ArrowLeft, Lightbulb
} from "lucide-react";
import { QuizView } from "@/components/quiz/QuizView";

const topics = [
  { id: "water", name: "Water Conservation", icon: Droplets, color: "text-blue-600" },
  { id: "air", name: "Air Pollution", icon: Wind, color: "text-sky-500" },
  { id: "deforestation", name: "Deforestation", icon: Trees, color: "text-amber-700" },
  { id: "climate", name: "Climate Change", icon: Sun, color: "text-orange-500" },
  { id: "waste", name: "Waste Management", icon: Trash2, color: "text-gray-600" },
  { id: "biodiversity", name: "Biodiversity", icon: Leaf, color: "text-green-600" },
  { id: "renewable", name: "Renewable Energy", icon: Zap, color: "text-yellow-500" },
  { id: "soil", name: "Soil Health", icon: Mountain, color: "text-amber-600" },
  { id: "ocean", name: "Ocean Pollution", icon: Waves, color: "text-blue-700" },
  { id: "wildlife", name: "Wildlife Protection", icon: PawPrint, color: "text-emerald-600" },
];

const QuizLearning = () => {
  const [selectedTopic, setSelectedTopic] = useState<string | null>(null);

  const currentTopic = topics.find(t => t.id === selectedTopic);

  if (selectedTopic && currentTopic) {
    return (
      <div className="min-h-screen bg-background">
        {/* Navbar */}
        <nav className="bg-primary text-primary-foreground shadow-md sticky top-0 z-10">
          <div className="container mx-auto px-4 py-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <Leaf className="h-8 w-8" />
                <h1 className="text-2xl font-bold">Environmental Buddy</h1>
              </div>
              <Badge variant="secondary" className="px-4 py-2 text-sm font-medium">
                Quiz & Learning
              </Badge>
            </div>
          </div>
        </nav>

        {/* Content */}
        <div className="container mx-auto px-4 py-8">
          <Button 
            variant="outline" 
            onClick={() => setSelectedTopic(null)}
            className="mb-6"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Topics
          </Button>

          <QuizView topic={currentTopic} />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Navbar */}
      <nav className="bg-primary text-primary-foreground shadow-md">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Leaf className="h-8 w-8" />
              <h1 className="text-2xl font-bold">Environmental Buddy</h1>
            </div>
            <Badge variant="secondary" className="px-4 py-2 text-sm font-medium">
              Quiz & Learning
            </Badge>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-br from-primary/10 to-accent/10 py-12">
        <div className="container mx-auto px-4 text-center">
          <div className="flex justify-center mb-4">
            <Award className="h-16 w-16 text-primary" />
          </div>
          <h2 className="text-4xl font-bold text-foreground mb-4">
            Learn About Our Environment
          </h2>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Choose a topic below to test your knowledge with interactive quizzes and explore mind maps
          </p>
        </div>
      </section>

      {/* Topics Grid */}
      <section className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {topics.map((topic) => {
            const Icon = topic.icon;
            return (
              <Card
                key={topic.id}
                onClick={() => setSelectedTopic(topic.id)}
                className="p-6 cursor-pointer transition-all duration-300 hover:shadow-lg hover:-translate-y-1 border-2 hover:border-primary/50 bg-card"
              >
                <div className="flex flex-col items-center text-center gap-4">
                  <div className="p-4 rounded-full bg-primary/10">
                    <Icon className={`h-10 w-10 ${topic.color}`} />
                  </div>
                  <h3 className="font-semibold text-lg text-card-foreground">
                    {topic.name}
                  </h3>
                  <div className="flex items-center gap-1 text-sm text-muted-foreground">
                    <Lightbulb className="h-4 w-4" />
                    <span>3 Levels</span>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      </section>
    </div>
  );
};

export default QuizLearning;
