export interface Question {
  question: string;
  options: string[];
  correctAnswer: number;
}

export interface QuizData {
  [topicId: string]: {
    [level: number]: Question[];
  };
}

export const quizData: QuizData = {
  water: {
    1: [
      {
        question: "What percentage of Earth's water is freshwater?",
        options: ["3%", "10%", "25%", "50%"],
        correctAnswer: 0
      },
      {
        question: "Which household activity uses the most water?",
        options: ["Washing dishes", "Taking showers", "Flushing toilets", "Watering lawn"],
        correctAnswer: 3
      },
      {
        question: "How many liters of water does a typical shower use per minute?",
        options: ["3 liters", "9 liters", "15 liters", "25 liters"],
        correctAnswer: 1
      }
    ],
    2: [
      {
        question: "What is the best way to reduce water usage in agriculture?",
        options: ["Use more pesticides", "Implement drip irrigation", "Increase rainfall", "Plant more crops"],
        correctAnswer: 1
      },
      {
        question: "Which method is most effective for household water conservation?",
        options: ["Installing low-flow fixtures", "Taking longer showers", "Washing dishes by hand", "Using hot water"],
        correctAnswer: 0
      },
      {
        question: "What percentage of household water can be saved by fixing leaks?",
        options: ["5%", "10%", "20%", "40%"],
        correctAnswer: 2
      },
      {
        question: "Which appliance certification indicates water efficiency?",
        options: ["Energy Star", "WaterSense", "Blue Label", "Green Seal"],
        correctAnswer: 1
      }
    ],
    3: [
      {
        question: "A city of 100,000 people reduces per-capita water use from 150 to 100 liters/day. How many liters are saved annually?",
        options: ["1.8 million liters", "18 million liters", "182 million liters", "1.8 billion liters"],
        correctAnswer: 3
      },
      {
        question: "Which policy combination would most effectively address water scarcity?",
        options: ["Price controls and subsidies", "Tiered pricing and conservation education", "Rationing only", "Technology bans"],
        correctAnswer: 1
      },
      {
        question: "What is the primary challenge in implementing rainwater harvesting in urban areas?",
        options: ["Cost of materials", "Water quality concerns", "Storage space and infrastructure", "Government regulations"],
        correctAnswer: 2
      },
      {
        question: "How does watershed management contribute to water conservation?",
        options: ["By building more dams", "By protecting vegetation and soil", "By increasing evaporation", "By diverting rivers"],
        correctAnswer: 1
      }
    ]
  },
  air: {
    1: [
      {
        question: "Which gas makes up most of Earth's atmosphere?",
        options: ["Oxygen", "Nitrogen", "Carbon dioxide", "Hydrogen"],
        correctAnswer: 1
      },
      {
        question: "What is the main source of air pollution in cities?",
        options: ["Trees", "Vehicle emissions", "Rain", "Wind"],
        correctAnswer: 1
      },
      {
        question: "Which of these is a greenhouse gas?",
        options: ["Oxygen", "Nitrogen", "Carbon dioxide", "Argon"],
        correctAnswer: 2
      }
    ],
    2: [
      {
        question: "What is the Air Quality Index (AQI) used for?",
        options: ["Measuring oxygen levels", "Reporting pollution levels", "Tracking weather", "Measuring humidity"],
        correctAnswer: 1
      },
      {
        question: "Which pollutant is primarily responsible for smog?",
        options: ["Carbon monoxide", "Ground-level ozone", "Methane", "Water vapor"],
        correctAnswer: 1
      },
      {
        question: "What is the most effective personal action to reduce air pollution?",
        options: ["Using public transport", "Buying more products", "Driving more", "Using air fresheners"],
        correctAnswer: 0
      },
      {
        question: "Which industry is a major contributor to sulfur dioxide emissions?",
        options: ["Technology", "Coal power plants", "Agriculture", "Tourism"],
        correctAnswer: 1
      }
    ],
    3: [
      {
        question: "How do particulate matter (PM2.5) particles affect human health?",
        options: ["They improve lung function", "They penetrate deep into lungs and bloodstream", "They only affect skin", "They have no health impact"],
        correctAnswer: 1
      },
      {
        question: "Which combination of policies is most effective for reducing urban air pollution?",
        options: ["Only vehicle restrictions", "Emission standards, green spaces, and public transit", "Building more roads", "Increasing industrial zones"],
        correctAnswer: 1
      },
      {
        question: "What role do trees play in improving air quality?",
        options: ["They produce pollutants", "They absorb CO2 and filter particulates", "They increase ozone levels", "They have no effect"],
        correctAnswer: 1
      },
      {
        question: "How does atmospheric inversion worsen air pollution?",
        options: ["It disperses pollutants quickly", "It traps pollutants near ground level", "It creates rain", "It increases wind speed"],
        correctAnswer: 1
      }
    ]
  },
  deforestation: {
    1: [
      {
        question: "What is deforestation?",
        options: ["Planting new trees", "Clearing forests for other uses", "Protecting forests", "Forest fires only"],
        correctAnswer: 1
      },
      {
        question: "Which region has the highest rate of deforestation?",
        options: ["Arctic", "Amazon rainforest", "Sahara desert", "Antarctica"],
        correctAnswer: 1
      },
      {
        question: "What is a major cause of deforestation?",
        options: ["Too much rain", "Agricultural expansion", "Wildlife protection", "Tourism"],
        correctAnswer: 1
      }
    ],
    2: [
      {
        question: "How does deforestation contribute to climate change?",
        options: ["It cools the planet", "It releases stored carbon dioxide", "It creates more oxygen", "It has no effect"],
        correctAnswer: 1
      },
      {
        question: "What is sustainable forestry?",
        options: ["Cutting all trees at once", "Managing forests to maintain biodiversity", "Avoiding all tree cutting", "Planting only one species"],
        correctAnswer: 1
      },
      {
        question: "Which product's production is NOT a major driver of deforestation?",
        options: ["Palm oil", "Beef", "Solar panels", "Soy"],
        correctAnswer: 2
      },
      {
        question: "What is the effect of deforestation on local rainfall?",
        options: ["Increases rainfall", "Decreases rainfall", "No effect", "Creates hurricanes"],
        correctAnswer: 1
      }
    ],
    3: [
      {
        question: "How does deforestation affect indigenous communities?",
        options: ["Improves their economy", "Destroys their homes and way of life", "Provides more jobs", "Increases their land"],
        correctAnswer: 1
      },
      {
        question: "What is the most effective policy approach to prevent deforestation?",
        options: ["Ignore the problem", "Combine economic incentives with law enforcement", "Only use punishment", "Allow unlimited logging"],
        correctAnswer: 1
      },
      {
        question: "How do forests act as carbon sinks?",
        options: ["They release carbon", "They absorb and store carbon through photosynthesis", "They convert carbon to methane", "They have no carbon interaction"],
        correctAnswer: 1
      },
      {
        question: "What is REDD+ in forest conservation?",
        options: ["A type of tree", "A program rewarding developing countries for reducing deforestation", "A logging company", "A forest disease"],
        correctAnswer: 1
      }
    ]
  },
  climate: {
    1: [
      {
        question: "What is the greenhouse effect?",
        options: ["Growing plants in greenhouses", "Gases trapping heat in atmosphere", "A cooling effect", "Cloud formation"],
        correctAnswer: 1
      },
      {
        question: "What is the main cause of recent climate change?",
        options: ["Solar flares", "Human activities", "Natural cycles only", "Volcanic eruptions"],
        correctAnswer: 1
      },
      {
        question: "Which is a sign of climate change?",
        options: ["Stable sea levels", "Rising global temperatures", "Constant weather patterns", "Increasing ice caps"],
        correctAnswer: 1
      }
    ],
    2: [
      {
        question: "What is the Paris Agreement about?",
        options: ["Air travel regulations", "Limiting global temperature rise", "Trade agreements", "City planning"],
        correctAnswer: 1
      },
      {
        question: "How do melting ice caps affect sea levels?",
        options: ["Lower sea levels", "Raise sea levels", "No effect", "Freeze the oceans"],
        correctAnswer: 1
      },
      {
        question: "What is carbon neutrality?",
        options: ["Producing unlimited carbon", "Balancing carbon emissions with removal", "Banning all carbon", "Ignoring carbon emissions"],
        correctAnswer: 1
      },
      {
        question: "Which sector produces the most greenhouse gases globally?",
        options: ["Tourism", "Energy production", "Education", "Healthcare"],
        correctAnswer: 1
      }
    ],
    3: [
      {
        question: "What are climate tipping points?",
        options: ["Small reversible changes", "Critical thresholds leading to irreversible changes", "Weather predictions", "Temperature measurements"],
        correctAnswer: 1
      },
      {
        question: "How does ocean acidification relate to climate change?",
        options: ["It doesn't", "Oceans absorb CO2, lowering pH", "It makes oceans alkaline", "It only affects rivers"],
        correctAnswer: 1
      },
      {
        question: "What is the most effective strategy for climate change mitigation?",
        options: ["Adapt only", "Combine emission reduction, renewable energy, and adaptation", "Do nothing", "Focus only on technology"],
        correctAnswer: 1
      },
      {
        question: "How do feedback loops accelerate climate change?",
        options: ["They slow warming", "Initial changes trigger effects that amplify warming", "They have no impact", "They reverse climate change"],
        correctAnswer: 1
      }
    ]
  },
  waste: {
    1: [
      {
        question: "What are the 3 R's of waste management?",
        options: ["Run, Race, Rest", "Reduce, Reuse, Recycle", "Read, Write, Remember", "Remove, Replace, Return"],
        correctAnswer: 1
      },
      {
        question: "Which material takes the longest to decompose?",
        options: ["Paper", "Glass", "Banana peel", "Wood"],
        correctAnswer: 1
      },
      {
        question: "What is composting?",
        options: ["Burning waste", "Decomposing organic matter into fertilizer", "Burying plastic", "Recycling metal"],
        correctAnswer: 1
      }
    ],
    2: [
      {
        question: "What is the primary problem with plastic waste?",
        options: ["It's too cheap", "It doesn't decompose easily", "It's too colorful", "It floats"],
        correctAnswer: 1
      },
      {
        question: "Which is an example of upcycling?",
        options: ["Throwing items away", "Creating new products from waste materials", "Burning waste", "Burying waste"],
        correctAnswer: 1
      },
      {
        question: "What percentage of plastic is actually recycled globally?",
        options: ["Less than 10%", "50%", "75%", "90%"],
        correctAnswer: 0
      },
      {
        question: "What is e-waste?",
        options: ["Electronic waste", "Energy waste", "Environmental waste", "Educational waste"],
        correctAnswer: 0
      }
    ],
    3: [
      {
        question: "What is the circular economy model?",
        options: ["Linear production and disposal", "Continuous reuse and recycling of materials", "One-time use of resources", "Ignoring waste"],
        correctAnswer: 1
      },
      {
        question: "How does incineration differ from landfilling in waste management?",
        options: ["Incineration reduces volume but may produce emissions", "They are identical", "Incineration always pollutes more", "Landfills are always better"],
        correctAnswer: 0
      },
      {
        question: "What role does extended producer responsibility (EPR) play?",
        options: ["Producers ignore their products", "Producers responsible for product lifecycle including disposal", "Only consumers handle waste", "Government handles everything"],
        correctAnswer: 1
      },
      {
        question: "How can zero-waste principles be applied at municipal level?",
        options: ["Ignore waste management", "Implement comprehensive recycling, composting, and reduction programs", "Only focus on landfills", "Ban all products"],
        correctAnswer: 1
      }
    ]
  },
  biodiversity: {
    1: [
      {
        question: "What is biodiversity?",
        options: ["One type of animal", "Variety of life on Earth", "A type of plant", "Only marine life"],
        correctAnswer: 1
      },
      {
        question: "Why is biodiversity important?",
        options: ["It's not important", "It supports ecosystem health and human survival", "Only for scientists", "Just for decoration"],
        correctAnswer: 1
      },
      {
        question: "What is an endangered species?",
        options: ["A common animal", "A species at risk of extinction", "A new species", "A domesticated animal"],
        correctAnswer: 1
      }
    ],
    2: [
      {
        question: "What is a biodiversity hotspot?",
        options: ["A zoo", "Region with high biodiversity under threat", "A warm place", "An empty area"],
        correctAnswer: 1
      },
      {
        question: "How does habitat fragmentation affect biodiversity?",
        options: ["Increases species", "Isolates populations and reduces genetic diversity", "Has no effect", "Creates new species"],
        correctAnswer: 1
      },
      {
        question: "What is the main cause of biodiversity loss?",
        options: ["Too many scientists", "Habitat destruction", "Natural selection", "Animal migration"],
        correctAnswer: 1
      },
      {
        question: "What role do pollinators play in biodiversity?",
        options: ["None", "Essential for plant reproduction and food chains", "They harm plants", "Only make honey"],
        correctAnswer: 1
      }
    ],
    3: [
      {
        question: "How does biodiversity contribute to ecosystem resilience?",
        options: ["It weakens ecosystems", "Greater variety enables recovery from disturbances", "It has no effect", "Only affects plants"],
        correctAnswer: 1
      },
      {
        question: "What is the relationship between biodiversity and ecosystem services?",
        options: ["No relationship", "Higher biodiversity supports more services like pollination and water purification", "Biodiversity reduces services", "Only commercial value matters"],
        correctAnswer: 1
      },
      {
        question: "How do invasive species threaten biodiversity?",
        options: ["They don't", "They outcompete native species for resources", "They always help", "They only affect plants"],
        correctAnswer: 1
      },
      {
        question: "What is ex-situ conservation?",
        options: ["Protecting species in natural habitats", "Conservation outside natural habitat (zoos, seed banks)", "Ignoring endangered species", "Only for plants"],
        correctAnswer: 1
      }
    ]
  },
  renewable: {
    1: [
      {
        question: "Which is a renewable energy source?",
        options: ["Coal", "Solar power", "Natural gas", "Oil"],
        correctAnswer: 1
      },
      {
        question: "What does renewable energy mean?",
        options: ["Energy that runs out quickly", "Energy from sources that replenish naturally", "Only wind energy", "Expensive energy"],
        correctAnswer: 1
      },
      {
        question: "Which device captures solar energy?",
        options: ["Wind turbine", "Solar panel", "Battery", "Generator"],
        correctAnswer: 1
      }
    ],
    2: [
      {
        question: "What is the main advantage of renewable energy?",
        options: ["Always expensive", "Low environmental impact and sustainable", "Needs fossil fuels", "Only works at night"],
        correctAnswer: 1
      },
      {
        question: "Which is NOT a renewable energy source?",
        options: ["Wind", "Nuclear", "Hydroelectric", "Geothermal"],
        correctAnswer: 1
      },
      {
        question: "What is energy storage important for renewable energy?",
        options: ["It's not important", "Provides power when sun/wind unavailable", "Increases costs only", "Reduces efficiency"],
        correctAnswer: 1
      },
      {
        question: "How does wind energy work?",
        options: ["Burning wind", "Turbines convert kinetic energy to electricity", "Storing wind in tanks", "Creating artificial wind"],
        correctAnswer: 1
      }
    ],
    3: [
      {
        question: "What is the capacity factor of renewable energy?",
        options: ["How much it costs", "Ratio of actual output to potential maximum output", "Storage capacity", "Installation time"],
        correctAnswer: 1
      },
      {
        question: "How can grid infrastructure adapt to intermittent renewable sources?",
        options: ["Ignore the problem", "Smart grids, storage, and diverse sources", "Use only fossil fuels", "Reduce electricity use"],
        correctAnswer: 1
      },
      {
        question: "What are the environmental impacts of hydroelectric dams?",
        options: ["None", "Can disrupt ecosystems and displace communities", "Only positive impacts", "Same as coal"],
        correctAnswer: 1
      },
      {
        question: "How does geothermal energy differ from other renewables?",
        options: ["It's not renewable", "Provides consistent baseload power unlike solar/wind", "Only works in winter", "Most expensive option"],
        correctAnswer: 1
      }
    ]
  },
  soil: {
    1: [
      {
        question: "What is soil made of?",
        options: ["Only dirt", "Minerals, organic matter, water, and air", "Just rocks", "Only sand"],
        correctAnswer: 1
      },
      {
        question: "Why is soil important?",
        options: ["It's not important", "Supports plant growth and filters water", "Only for construction", "Just for digging"],
        correctAnswer: 1
      },
      {
        question: "What is soil erosion?",
        options: ["Soil getting healthier", "Loss of topsoil due to wind or water", "Adding nutrients", "Planting crops"],
        correctAnswer: 1
      }
    ],
    2: [
      {
        question: "What causes soil degradation?",
        options: ["Planting trees", "Overfarming, deforestation, and pollution", "Natural rainfall", "Wildlife"],
        correctAnswer: 1
      },
      {
        question: "What is composting's effect on soil?",
        options: ["Damages soil", "Adds nutrients and improves structure", "No effect", "Only for flowers"],
        correctAnswer: 1
      },
      {
        question: "Which farming practice helps prevent soil erosion?",
        options: ["Clear-cutting forests", "Contour plowing and cover crops", "Overgrazing", "Monoculture"],
        correctAnswer: 1
      },
      {
        question: "What is topsoil?",
        options: ["Bottom layer", "Nutrient-rich upper layer of soil", "Subsoil", "Bedrock"],
        correctAnswer: 1
      }
    ],
    3: [
      {
        question: "How does soil organic matter affect carbon sequestration?",
        options: ["Releases all carbon", "Stores carbon removed from atmosphere", "No relationship", "Only affects nitrogen"],
        correctAnswer: 1
      },
      {
        question: "What is regenerative agriculture?",
        options: ["Using more chemicals", "Farming practices that restore soil health", "Destroying farmland", "Industrial farming only"],
        correctAnswer: 1
      },
      {
        question: "How do soil microorganisms contribute to ecosystem health?",
        options: ["They don't", "Decompose matter, cycle nutrients, support plant growth", "Only cause disease", "Harm plants"],
        correctAnswer: 1
      },
      {
        question: "What is desertification and how is it related to soil health?",
        options: ["Creating deserts for tourism", "Land degradation making productive land barren", "Planting cacti", "Natural desert expansion"],
        correctAnswer: 1
      }
    ]
  },
  ocean: {
    1: [
      {
        question: "What percentage of Earth is covered by oceans?",
        options: ["50%", "71%", "30%", "90%"],
        correctAnswer: 1
      },
      {
        question: "What is the Great Pacific Garbage Patch?",
        options: ["A coral reef", "Large area of plastic debris in ocean", "An island", "A whale migration path"],
        correctAnswer: 1
      },
      {
        question: "Which is a major ocean pollutant?",
        options: ["Fish", "Plastic", "Salt", "Seaweed"],
        correctAnswer: 1
      }
    ],
    2: [
      {
        question: "How does plastic affect marine life?",
        options: ["Helps them grow", "Animals ingest it and get entangled", "No effect", "Provides shelter"],
        correctAnswer: 1
      },
      {
        question: "What is ocean acidification?",
        options: ["Ocean becoming cleaner", "Ocean pH decreasing due to CO2 absorption", "Ocean getting saltier", "Ocean temperature rising"],
        correctAnswer: 1
      },
      {
        question: "Which human activity most pollutes oceans?",
        options: ["Swimming", "Industrial waste and plastic disposal", "Sailing", "Fishing with nets"],
        correctAnswer: 1
      },
      {
        question: "What are microplastics?",
        options: ["Large plastic items", "Tiny plastic particles less than 5mm", "Natural materials", "Biodegradable plastics"],
        correctAnswer: 1
      }
    ],
    3: [
      {
        question: "How does ocean pollution affect the food chain?",
        options: ["No effect", "Toxins accumulate and concentrate up the chain", "Only affects plants", "Improves nutrition"],
        correctAnswer: 1
      },
      {
        question: "What is the dead zone phenomenon in oceans?",
        options: ["Where no fish live naturally", "Low-oxygen areas where marine life can't survive", "Deep ocean trenches", "Polar regions"],
        correctAnswer: 1
      },
      {
        question: "How do chemical pollutants like oil spills impact marine ecosystems?",
        options: ["They evaporate harmlessly", "Coat organisms, block sunlight, poison wildlife", "Only affect the surface", "Improve water quality"],
        correctAnswer: 1
      },
      {
        question: "What role do oceans play in climate regulation?",
        options: ["None", "Absorb CO2 and heat, regulate global temperatures", "Only create waves", "Increase global warming"],
        correctAnswer: 1
      }
    ]
  },
  wildlife: {
    1: [
      {
        question: "What does wildlife protection mean?",
        options: ["Hunting animals", "Conserving and preserving animal species", "Building zoos only", "Avoiding nature"],
        correctAnswer: 1
      },
      {
        question: "What is a wildlife sanctuary?",
        options: ["A hospital", "Protected area for animals to live safely", "A pet store", "A farm"],
        correctAnswer: 1
      },
      {
        question: "Why do animals become extinct?",
        options: ["They choose to", "Habitat loss, hunting, climate change", "Natural aging", "Migration"],
        correctAnswer: 1
      }
    ],
    2: [
      {
        question: "What is poaching?",
        options: ["Legal hunting", "Illegal hunting or capturing of wildlife", "Wildlife photography", "Animal rescue"],
        correctAnswer: 1
      },
      {
        question: "How do corridors help wildlife?",
        options: ["They don't", "Connect habitats allowing safe movement", "Block animal paths", "Only for decoration"],
        correctAnswer: 1
      },
      {
        question: "What is the purpose of wildlife conservation laws?",
        options: ["Limit human activities", "Protect endangered species and habitats", "Generate revenue only", "Restrict tourism"],
        correctAnswer: 1
      },
      {
        question: "Which organization is known for wildlife protection?",
        options: ["FIFA", "World Wildlife Fund (WWF)", "NASA", "UNESCO only"],
        correctAnswer: 1
      }
    ],
    3: [
      {
        question: "How does habitat fragmentation affect wildlife populations?",
        options: ["Increases populations", "Isolates groups, reduces genetic diversity, threatens survival", "Has no impact", "Only affects plants"],
        correctAnswer: 1
      },
      {
        question: "What is the concept of keystone species?",
        options: ["Common animals", "Species whose presence is crucial for ecosystem stability", "Largest animals", "Domesticated animals"],
        correctAnswer: 1
      },
      {
        question: "How can ecotourism support wildlife protection?",
        options: ["It can't", "Generates funds and awareness while minimizing disturbance", "Harms all wildlife", "Only benefits tour operators"],
        correctAnswer: 1
      },
      {
        question: "What is the human-wildlife conflict and how can it be mitigated?",
        options: ["Humans vs animals fight", "Competition for resources; solved through education and barriers", "Natural phenomenon only", "Cannot be solved"],
        correctAnswer: 1
      }
    ]
  }
};
