import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Network, Trophy, ChevronDown, ChevronUp } from "lucide-react";
import { QuizLevel } from "./QuizLevel";
import { quizData } from "./quizData";

interface Topic {
  id: string;
  name: string;
  icon: React.ComponentType<{ className?: string }>;
  color: string;
}

interface QuizViewProps {
  topic: Topic;
}

export const QuizView = ({ topic }: QuizViewProps) => {
  const [openLevel, setOpenLevel] = useState<number | null>(1);
  const [scores, setScores] = useState<{ [key: number]: { current: number; total: number } }>({});
  
  const Icon = topic.icon;
  const topicQuizzes = quizData[topic.id] || {};
  
  const totalScore = Object.values(scores).reduce((sum, s) => sum + s.current, 0);
  const totalQuestions = Object.values(scores).reduce((sum, s) => sum + s.total, 0);

  const handleScoreUpdate = (level: number, score: number, total: number) => {
    setScores(prev => ({
      ...prev,
      [level]: { current: score, total }
    }));
  };

  return (
    <div className="space-y-6">
      {/* Topic Header */}
      <Card className="p-6 bg-gradient-to-br from-primary/5 to-accent/5 border-2">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4">
            <div className="p-4 rounded-full bg-primary/10">
              <Icon className={`h-12 w-12 ${topic.color}`} />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-foreground">{topic.name}</h2>
              <p className="text-muted-foreground mt-1">Test your knowledge across three levels</p>
            </div>
          </div>
          
          {totalQuestions > 0 && (
            <div className="flex items-center gap-3 bg-card p-4 rounded-lg border">
              <Trophy className="h-6 w-6 text-success" />
              <div>
                <p className="text-sm text-muted-foreground">Total Score</p>
                <p className="text-2xl font-bold text-foreground">
                  {totalScore}/{totalQuestions}
                </p>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* Mind Map Placeholder */}
      <Card className="p-6 bg-card border-2 border-dashed">
        <div className="flex items-center justify-between flex-wrap gap-4">
          <div className="flex items-center gap-3">
            <Network className="h-6 w-6 text-muted-foreground" />
            <div>
              <h3 className="font-semibold text-lg text-foreground">Mind Map</h3>
              <p className="text-sm text-muted-foreground">
                Visual overview of {topic.name} concepts
              </p>
            </div>
          </div>
          <Button disabled variant="secondary">
            Generate Mind Map (Coming Soon)
          </Button>
        </div>
      </Card>

      {/* Quiz Levels */}
      <div className="space-y-4">
        <h3 className="text-2xl font-bold text-foreground flex items-center gap-2">
          <Trophy className="h-6 w-6 text-primary" />
          Quiz Levels
        </h3>
        
        {[1, 2, 3].map((level) => {
          const levelNames = ["Basics", "Apply", "Solve"];
          const levelColors = [
            "bg-green-500/10 text-green-700 border-green-500/20",
            "bg-blue-500/10 text-blue-700 border-blue-500/20",
            "bg-purple-500/10 text-purple-700 border-purple-500/20"
          ];
          
          const isOpen = openLevel === level;
          const questions = topicQuizzes[level] || [];
          const levelScore = scores[level];
          
          return (
            <Card key={level} className="overflow-hidden border-2">
              <div
                className="p-4 cursor-pointer hover:bg-muted/50 transition-colors"
                onClick={() => setOpenLevel(isOpen ? null : level)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <Badge className={`px-3 py-1 ${levelColors[level - 1]}`}>
                      Level {level}
                    </Badge>
                    <div>
                      <h4 className="font-semibold text-lg text-foreground">
                        {levelNames[level - 1]}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {questions.length} questions
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    {levelScore && (
                      <div className="text-right">
                        <p className="text-sm text-muted-foreground">Score</p>
                        <p className="font-bold text-foreground">
                          {levelScore.current}/{levelScore.total}
                        </p>
                      </div>
                    )}
                    {isOpen ? (
                      <ChevronUp className="h-5 w-5 text-muted-foreground" />
                    ) : (
                      <ChevronDown className="h-5 w-5 text-muted-foreground" />
                    )}
                  </div>
                </div>
              </div>
              
              {isOpen && (
                <div className="border-t p-6 bg-muted/20">
                  <QuizLevel
                    questions={questions}
                    level={level}
                    onScoreUpdate={(score, total) => handleScoreUpdate(level, score, total)}
                  />
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
};
