import { useState, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Check, X } from "lucide-react";
import { cn } from "@/lib/utils";

interface Question {
  question: string;
  options: string[];
  correctAnswer: number;
}

interface QuizLevelProps {
  questions: Question[];
  level: number;
  onScoreUpdate: (score: number, total: number) => void;
}

export const QuizLevel = ({ questions, level, onScoreUpdate }: QuizLevelProps) => {
  const [selectedAnswers, setSelectedAnswers] = useState<{ [key: number]: number }>({});
  const [revealedQuestions, setRevealedQuestions] = useState<Set<number>>(new Set());

  useEffect(() => {
    // Calculate score whenever answers change
    const correctCount = Object.entries(selectedAnswers).filter(
      ([questionIdx, answerIdx]) => {
        const qIdx = parseInt(questionIdx);
        return questions[qIdx]?.correctAnswer === answerIdx;
      }
    ).length;
    
    onScoreUpdate(correctCount, questions.length);
  }, [selectedAnswers, questions, onScoreUpdate]);

  const handleAnswerSelect = (questionIndex: number, optionIndex: number) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [questionIndex]: optionIndex
    }));
    setRevealedQuestions(prev => new Set(prev).add(questionIndex));
  };

  const isCorrectAnswer = (questionIndex: number, optionIndex: number) => {
    return questions[questionIndex].correctAnswer === optionIndex;
  };

  const isSelectedAnswer = (questionIndex: number, optionIndex: number) => {
    return selectedAnswers[questionIndex] === optionIndex;
  };

  const isRevealed = (questionIndex: number) => {
    return revealedQuestions.has(questionIndex);
  };

  if (!questions || questions.length === 0) {
    return (
      <div className="text-center py-8 text-muted-foreground">
        No questions available for this level yet.
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {questions.map((q, qIdx) => {
        const revealed = isRevealed(qIdx);
        const selectedAns = selectedAnswers[qIdx];
        const isCorrect = revealed && selectedAns !== undefined && isCorrectAnswer(qIdx, selectedAns);

        return (
          <Card key={qIdx} className="p-5 bg-card border-2">
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <div className="flex-shrink-0 w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-primary font-semibold">
                  {qIdx + 1}
                </div>
                <p className="text-base font-medium text-foreground flex-1 pt-1">
                  {q.question}
                </p>
              </div>

              <div className="grid gap-3 ml-11">
                {q.options.map((option, oIdx) => {
                  const isSelected = isSelectedAnswer(qIdx, oIdx);
                  const isCorrectOpt = isCorrectAnswer(qIdx, oIdx);
                  const showCorrect = revealed && isCorrectOpt;
                  const showIncorrect = revealed && isSelected && !isCorrectOpt;

                  return (
                    <Button
                      key={oIdx}
                      variant="outline"
                      onClick={() => !revealed && handleAnswerSelect(qIdx, oIdx)}
                      disabled={revealed}
                      className={cn(
                        "justify-start text-left h-auto py-3 px-4 relative",
                        showCorrect && "bg-success/10 border-success hover:bg-success/20",
                        showIncorrect && "bg-destructive/10 border-destructive hover:bg-destructive/20",
                        !revealed && "hover:bg-accent/50"
                      )}
                    >
                      <span className="flex-1">{option}</span>
                      {showCorrect && (
                        <Check className="h-5 w-5 text-success ml-2 flex-shrink-0" />
                      )}
                      {showIncorrect && (
                        <X className="h-5 w-5 text-destructive ml-2 flex-shrink-0" />
                      )}
                    </Button>
                  );
                })}
              </div>

              {revealed && (
                <div className={cn(
                  "ml-11 p-3 rounded-lg text-sm font-medium flex items-center gap-2",
                  isCorrect ? "bg-success/10 text-success" : "bg-destructive/10 text-destructive"
                )}>
                  {isCorrect ? (
                    <>
                      <Check className="h-4 w-4" />
                      Correct! Well done!
                    </>
                  ) : (
                    <>
                      <X className="h-4 w-4" />
                      Incorrect. The correct answer is highlighted above.
                    </>
                  )}
                </div>
              )}
            </div>
          </Card>
        );
      })}
    </div>
  );
};
